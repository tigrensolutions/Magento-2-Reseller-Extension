<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Block\Adminhtml\Group;

/**
 * Class Edit
 * @package Tigren\Reseller\Block\Adminhtml\Group
 */
class Edit extends \Magento\Backend\Block\Widget\Form\Container
{
    /**
     * @var \Magento\Framework\Registry|null
     */
    protected $_coreRegistry = null;

    /**
     * Edit constructor.
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }

    /**
     * @return \Magento\Framework\Phrase|string
     */
    public function getHeaderText()
    {
        if ($this->_coreRegistry->registry('reseller_group')->getId()) {
            return __("Edit Group '%1'",
                $this->escapeHtml($this->_coreRegistry->registry('reseller_group')->getGroupName()));
        } else {
            return __('New Group');
        }
    }

    /**
     *
     */
    protected function _construct()
    {
        $this->_objectId = 'group_id';
        $this->_blockGroup = 'Tigren_Reseller';
        $this->_controller = 'adminhtml_group';

        parent::_construct();

        if ($this->_isAllowedAction('Tigren_Reseller::save')) {
            $this->buttonList->update('save', 'label', __('Save Group'));
            $this->buttonList->add(
                'saveandcontinue',
                [
                    'label' => __('Save and Continue Edit'),
                    'class' => 'save',
                    'data_attribute' => [
                        'mage-init' => [
                            'button' => ['event' => 'saveAndContinueEdit', 'target' => '#edit_form'],
                        ],
                    ]
                ],
                -100
            );
        } else {
            $this->buttonList->remove('save');
        }

        if ($this->_isAllowedAction('Tigren_Reseller::group_delete')) {
            $this->buttonList->update('delete', 'label', __('Delete Group'));
        } else {
            $this->buttonList->remove('delete');
        }

        if ($this->_coreRegistry->registry('reseller_group')->getId()) {
            $this->buttonList->remove('reset');
        }
    }

    /**
     * @param $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

    /**
     * @return string
     */
    protected function _getSaveAndContinueUrl()
    {
        return $this->getUrl('reseller/*/save', ['_current' => true, 'back' => 'edit', 'active_tab' => '']);
    }
}
