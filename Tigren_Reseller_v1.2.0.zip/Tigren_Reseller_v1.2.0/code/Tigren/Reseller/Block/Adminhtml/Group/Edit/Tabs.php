<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Block\Adminhtml\Group\Edit;

use Magento\Backend\Block\Template\Context;
use Magento\Backend\Model\Auth\Session;
use Magento\Framework\Json\EncoderInterface;
use Magento\Framework\Registry;
use Magento\Framework\Translate\InlineInterface;

/**
 * Class Tabs
 * @package Tigren\Reseller\Block\Adminhtml\Group\Edit
 */
class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    /**
     * @var InlineInterface
     */
    protected $_translateInline;

    /**
     * @var Registry|null
     */
    protected $_coreRegistry = null;

    /**
     * Tabs constructor.
     * @param Context $context
     * @param EncoderInterface $jsonEncoder
     * @param Session $authSession
     * @param Registry $registry
     * @param InlineInterface $translateInline
     * @param array $data
     */
    public function __construct(
        Context $context,
        EncoderInterface $jsonEncoder,
        Session $authSession,
        Registry $registry,
        InlineInterface $translateInline,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        $this->_translateInline = $translateInline;
        parent::__construct($context, $jsonEncoder, $authSession, $data);
    }

    /**
     * @return mixed
     */
    public function getBlock()
    {
        if (!$this->getData('reseller_group') instanceof \Tigren\Reseller\Model\ResellerGroup) {
            $this->setData('reseller_group', $this->_coreRegistry->registry('reseller_group'));
        }
        return $this->getData('reseller_group');
    }

    /**
     *
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('reseller_group_edit_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Group'));
    }

    /**
     * @return \Magento\Backend\Block\Widget\Tabs
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _prepareLayout()
    {
        $this->addTab(
            'reseller_group_edit_tab_main',
            [
                'label' => __('Group Information'),
                'content' => $this->getLayout()->createBlock(
                    'Tigren\Reseller\Block\Adminhtml\Group\Edit\Tab\Main'
                )->toHtml()
            ]
        );

        return parent::_prepareLayout();
    }

    /**
     * Translate html content
     *
     * @param string $html
     * @return string
     */
    protected function _translateHtml($html)
    {
        $this->_translateInline->processResponseBody($html);
        return $html;
    }
}