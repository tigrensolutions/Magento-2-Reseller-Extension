<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Block\Adminhtml;

/**
 * Class Group
 * @package Tigren\Reseller\Block\Adminhtml
 */
class Group extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     *
     */
    protected function _construct()
    {
        $this->_controller = 'adminhtml_group';
        $this->_blockGroup = 'Tigren_Reseller';
        $this->_headerText = __('Manage Groups');

        parent::_construct();

        if ($this->_isAllowedAction('Tigren_Reseller::save')) {
            $this->buttonList->update('add', 'label', __('Add New Group'));
        } else {
            $this->buttonList->remove('add');
        }
    }

    /**
     * @param $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}