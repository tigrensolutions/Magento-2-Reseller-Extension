<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Block\Adminhtml\Form\Field;

/**
 * Class Question
 * @package Tigren\Reseller\Block\Adminhtml\Form\Field
 */
class Question extends \Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray
{
    /**
     *
     */
    protected function _prepareToRender()
    {
        $this->addColumn(
            'question',
            ['label' => __('Question'), 'size' => '350px']
        );
        $this->_addAfter = false;
        $this->_addButtonLabel = __('Add Question');
    }
}
