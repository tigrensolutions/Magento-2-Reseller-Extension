<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Block\Adminhtml;

/**
 * Class Submitted
 * @package Tigren\Reseller\Block\Adminhtml
 */
class Submitted extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     *
     */
    protected function _construct()
    {
        $this->_controller = 'adminhtml_submitted';
        $this->_blockGroup = 'Tigren_Reseller';
        $this->_headerText = __('Manage Customer Submitted');

        parent::_construct();

        $this->buttonList->remove('add');
    }

    /**
     * @param $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
