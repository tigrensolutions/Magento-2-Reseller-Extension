<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Block\Adminhtml\Submitted\Edit;

/**
 * Class Form
 * @package Tigren\Reseller\Block\Adminhtml\Submitted\Edit
 */
class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    /**
     *
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('submitted_form');
        $this->setTitle(__('Submitted Information'));
    }

    /**
     * @return \Magento\Backend\Block\Widget\Form\Generic
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _prepareForm()
    {
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            [
                'data' => [
                    'id' => 'edit_form',
                    'class' => 'admin__scope-old',
                    'action' => $this->getUrl('reseller/submitted/save'),
                    'method' => 'post',
                ],
            ]
        );
        $form->setUseContainer(true);
        $this->setForm($form);
        return parent::_prepareForm();
    }
}
