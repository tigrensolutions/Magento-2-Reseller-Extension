<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Block\Adminhtml\Submitted\Edit\Tab;

use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Model\Address\Mapper;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class Main
 * @package Tigren\Reseller\Block\Adminhtml\Submitted\Edit\Tab
 */
class Main extends \Magento\Framework\View\Element\Template implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var string
     */
    protected $_template = "Tigren_Reseller::submitted/view.phtml";

    /**
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * @var \Tigren\Reseller\Model\ResellerSubmitted
     */
    protected $_submittedFactory;

    /**
     * @var \Tigren\Reseller\Model\ResourceModel\ResellerSubmitted\CollectionFactory
     */
    protected $_submittedCollectionFactory;

    /**
     * @var \Tigren\Reseller\Helper\Data
     */
    protected $_submittedHelper;

    /**
     * @var AccountManagementInterface
     */
    protected $accountManagement;

    /**
     * @var \Magento\Customer\Helper\Address
     */
    protected $addressHelper;

    /**
     * @var Mapper
     */
    protected $addressMapper;

    /**
     * @var \Tigren\Reseller\Model\Submitted\Source\Status
     */
    protected $_statusArray;

    /**
     * @var \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory
     */
    protected $_reselllerGroupCollectionFactory;

    /**
     * Main constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Tigren\Reseller\Model\ResellerSubmitted $submittedFactory
     * @param \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory $reselllerGroupCollectionFactory
     * @param \Tigren\Reseller\Model\ResourceModel\ResellerSubmitted\CollectionFactory $submittedCollectionFactory
     * @param \Tigren\Reseller\Helper\Data $submittedHelper
     * @param AccountManagementInterface $accountManagement
     * @param \Magento\Customer\Helper\Address $addressHelper
     * @param Mapper $addressMapper
     * @param \Tigren\Reseller\Model\Submitted\Source\Status $statusArray
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Tigren\Reseller\Model\ResellerSubmitted $submittedFactory,
        \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory $reselllerGroupCollectionFactory,
        \Tigren\Reseller\Model\ResourceModel\ResellerSubmitted\CollectionFactory $submittedCollectionFactory,
        \Tigren\Reseller\Helper\Data $submittedHelper,
        AccountManagementInterface $accountManagement,
        \Magento\Customer\Helper\Address $addressHelper,
        Mapper $addressMapper,
        \Tigren\Reseller\Model\Submitted\Source\Status $statusArray,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_coreRegistry = $coreRegistry;
        $this->_submittedFactory = $submittedFactory;
        $this->_submittedCollectionFactory = $submittedCollectionFactory;
        $this->_submittedHelper = $submittedHelper;
        $this->accountManagement = $accountManagement;
        $this->addressHelper = $addressHelper;
        $this->addressMapper = $addressMapper;
        $this->_statusArray = $statusArray;
        $this->_reselllerGroupCollectionFactory = $reselllerGroupCollectionFactory;
    }

    /**
     * @return array
     */
    public function getStatusArray()
    {
        return $this->_statusArray->toOptionArray();
    }

    /**
     * @return array
     */
    public function getResellerArray()
    {
        $resellerGroups = $this->_reselllerGroupCollectionFactory->create();
        $arr = [];
        foreach ($resellerGroups as $resellerGroup) {
            $arr[] = [
                'label' => $resellerGroup->getGroupName(),
                'value' => $resellerGroup->getId()
            ];
        }
        return $arr;
    }

    /**
     * @return string
     */
    public function getBaseUrl()
    {
        return $this->_submittedHelper->getBaseUrl();
    }

    /**
     * @return \Magento\Framework\Phrase|string
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getBillingAddressHtml()
    {
        try {
            $address = $this->accountManagement->getDefaultBillingAddress($this->getdataForm()->getCustomerId());
        } catch (NoSuchEntityException $e) {
            return __('The customer does not have default billing address.');
        }

        if ($address === null) {
            return __('The customer does not have default billing address.');
        }

        return $this->addressHelper->getFormatTypeRenderer('html')->renderArray($this->addressMapper->toFlatArray($address));
    }

    /**
     * @return \Tigren\Reseller\Model\ResellerSubmitted
     */
    public function getdataForm()
    {
        $id = $this->getRequest()->getParam('submitted_id');
        $model = $this->_submittedFactory->load($id);
        return $model;
    }

    /**
     * Prepare label for tab.
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('General Information');
    }

    /**
     * Prepare title for tab.
     *
     * @return string
     */
    public function getTabTitle()
    {
        return __('General Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }
}
