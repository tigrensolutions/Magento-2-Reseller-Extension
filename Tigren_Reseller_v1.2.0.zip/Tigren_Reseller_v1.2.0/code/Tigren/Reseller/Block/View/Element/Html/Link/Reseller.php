<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Block\View\Element\Html\Link;

/**
 * Class Reseller
 * @package Tigren\Reseller\Block\View\Element\Html\Link
 */
class Reseller extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Framework\App\DefaultPathInterface
     */
    protected $_defaultPath;
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;
    /**
     * @var \Tigren\Reseller\Model\ResellerGroupFactory
     */
    protected $_resellerGroupFactory;
    /**
     * @var \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory
     */
    protected $_resellerGroupCollectionFactory;

    /**
     * Reseller constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\App\DefaultPathInterface $defaultPath
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Tigren\Reseller\Model\ResellerGroupFactory $resellerGroupFactory
     * @param \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory $resellerGroupCollectionFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\App\DefaultPathInterface $defaultPath,
        \Magento\Customer\Model\Session $customerSession,
        \Tigren\Reseller\Model\ResellerGroupFactory $resellerGroupFactory,
        \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory $resellerGroupCollectionFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_defaultPath = $defaultPath;
        $this->_customerSession = $customerSession;
        $this->_resellerGroupFactory = $resellerGroupFactory;
        $this->_resellerGroupCollectionFactory = $resellerGroupCollectionFactory;
    }

    /**
     * @return string
     */
    protected function _toHtml()
    {
        if ($this->checkReseller($this->_customerSession->getCustomerId())) {
            return '';
        } else {
            if (false != $this->getTemplate()) {
                return parent::_toHtml();
            }

            $highlight = '';

            if ($this->getIsHighlighted()) {
                $highlight = ' current';
            }

            if ($this->isCurrent()) {
                $html = '<li class="nav item current">';
                $html .= '<strong>'
                    . $this->escapeHtml((string)new \Magento\Framework\Phrase($this->getLabel()))
                    . '</strong>';
                $html .= '</li>';
            } else {
                $html = '<li class="nav item' . $highlight . '"><a href="' . $this->escapeHtml($this->getHref()) . '"';
                $html .= $this->getTitle()
                    ? ' title="' . $this->escapeHtml((string)new \Magento\Framework\Phrase($this->getTitle())) . '"'
                    : '';
                $html .= $this->getAttributesHtml() . '>';

                if ($this->getIsHighlighted()) {
                    $html .= '<strong>';
                }

                $html .= $this->escapeHtml((string)new \Magento\Framework\Phrase($this->getLabel()));

                if ($this->getIsHighlighted()) {
                    $html .= '</strong>';
                }

                $html .= '</a></li>';
                return $html;
            }
        }

        return '';
    }

    /**
     * @param $customerId
     * @return bool
     */
    public function checkReseller($customerId)
    {
        $check = false;
        $collectionGroups = $this->_resellerGroupCollectionFactory->create();
        foreach ($collectionGroups as $collectionGroup) {
            $resellerGroupAllData = $this->_resellerGroupFactory->create()->load($collectionGroup->getId());
            $customersOfGroup = $resellerGroupAllData->getCustomer();
            if (in_array($customerId, $customersOfGroup)) {
                $check = true;
                break;
            }
        }
        return $check;
    }

    /**
     * @return bool
     */
    public function isCurrent()
    {
        return $this->getCurrent() || $this->getUrl($this->getPath()) == $this->getUrl($this->getMca());
    }

    /**
     * @return string
     */
    private function getMca()
    {
        $routeParts = [
            'module' => $this->_request->getModuleName(),
            'controller' => $this->_request->getControllerName(),
            'action' => $this->_request->getActionName(),
        ];

        $parts = [];
        foreach ($routeParts as $key => $value) {
            if (!empty($value) && $value != $this->_defaultPath->getPart($key)) {
                $parts[] = $value;
            }
        }
        return implode('/', $parts);
    }

    /**
     * @return string
     */
    public function getHref()
    {
        return $this->getUrl($this->getPath());
    }

    /**
     * @return string
     */
    private function getAttributesHtml()
    {
        $attributesHtml = '';
        $attributes = $this->getAttributes();
        if ($attributes) {
            foreach ($attributes as $attribute => $value) {
                $attributesHtml .= ' ' . $attribute . '="' . $this->escapeHtml($value) . '"';
            }
        }

        return $attributesHtml;
    }
}
