<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Block;

/**
 * Class Tab
 * @package Tigren\Reseller\Block
 */
class Tab extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Customer\Helper\Session\CurrentCustomer
     */
    protected $_currentCustomer;

    /**
     * @var \Tigren\Reseller\Model\ResourceModel\ResellerSubmitted\CollectionFactory
     */
    protected $_customerSubmitCollectionFactory;

    /**
     * Tab constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Customer\Helper\Session\CurrentCustomer $currentCustomer
     * @param \Tigren\Reseller\Model\ResourceModel\ResellerSubmitted\CollectionFactory $customerSubmitCollectionFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Customer\Helper\Session\CurrentCustomer $currentCustomer,
        \Tigren\Reseller\Model\ResourceModel\ResellerSubmitted\CollectionFactory $customerSubmitCollectionFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_currentCustomer = $currentCustomer;
        $this->_customerSubmitCollectionFactory = $customerSubmitCollectionFactory;
    }

    /**
     * @return bool|\Magento\Customer\Api\Data\CustomerInterface
     */
    public function getCustomerData()
    {
        if (!$this->_currentCustomer->getCustomerId()) {
            return false;
        }
        return $this->_currentCustomer->getCustomer();
    }

    /**
     * @param $id
     * @return string
     */
    public function getViewUrl($id)
    {
        return $this->getUrl('mycart/index/view', ['id' => $id]);
    }

    /**
     * @return bool
     */
    public function getCustomerSubmit()
    {
        $collection = $this->_customerSubmitCollectionFactory
            ->create()
            ->addFieldToFilter('customer_id', $this->_currentCustomer->getCustomerId());
        if ($collection->getSize()) {
            return true;
        } else {
            return false;
        }
    }
}
