<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Block;

/**
 * Class Form
 * @package Tigren\Reseller\Block
 */
class Form extends \Magento\Customer\Block\Form\Register
{
    /**
     * @var \Tigren\Reseller\Helper\Data
     */
    protected $_resellerHelper;

    /**
     * @var \Tigren\Reseller\Model\Submitted\Source\HearAboutUs
     */
    protected $_hearAboutUs;

    /**
     * Form constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Directory\Helper\Data $directoryHelper
     * @param \Magento\Framework\Json\EncoderInterface $jsonEncoder
     * @param \Magento\Framework\App\Cache\Type\Config $configCacheType
     * @param \Magento\Directory\Model\ResourceModel\Region\CollectionFactory $regionCollectionFactory
     * @param \Magento\Directory\Model\ResourceModel\Country\CollectionFactory $countryCollectionFactory
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Customer\Model\Url $customerUrl
     * @param \Tigren\Reseller\Helper\Data $resellerHelper
     * @param \Tigren\Reseller\Model\Submitted\Source\HearAboutUs $hearAboutUs
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Directory\Helper\Data $directoryHelper,
        \Magento\Framework\Json\EncoderInterface $jsonEncoder,
        \Magento\Framework\App\Cache\Type\Config $configCacheType,
        \Magento\Directory\Model\ResourceModel\Region\CollectionFactory $regionCollectionFactory,
        \Magento\Directory\Model\ResourceModel\Country\CollectionFactory $countryCollectionFactory,
        \Magento\Framework\Module\Manager $moduleManager,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Customer\Model\Url $customerUrl,
        \Tigren\Reseller\Helper\Data $resellerHelper,
        \Tigren\Reseller\Model\Submitted\Source\HearAboutUs $hearAboutUs,
        array $data = []
    ) {
        parent::__construct(
            $context,
            $directoryHelper,
            $jsonEncoder,
            $configCacheType,
            $regionCollectionFactory,
            $countryCollectionFactory,
            $moduleManager,
            $customerSession,
            $customerUrl,
            $data
        );
        $this->_resellerHelper = $resellerHelper;
        $this->_hearAboutUs = $hearAboutUs;
    }

    /**
     * @return mixed
     */
    public function getQuestionItem()
    {
        $data = $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Data::XML_PATH_QUESTION_ITEM);
        return json_decode($data);
    }

    /**
     * @return bool
     */
    public function isLoggedIn()
    {
        return $this->_customerSession->isLoggedIn();
    }

    /**
     * @return string
     */
    public function getFormAction()
    {
        return $this->getUrl('reseller/index/save', ['_secure' => true]);
    }

    /**
     * @return array
     */
    public function getHearAboutUs()
    {
        return $this->_hearAboutUs->toOptionArray();
    }
}
