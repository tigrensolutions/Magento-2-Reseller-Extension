<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'Tigren_Reseller',
    __DIR__
);