<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Model\ResourceModel\ResellerGroup;

/**
 * Class Collection
 * @package Tigren\Reseller\Model\ResourceModel\ResellerGroup
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var
     */
    protected $tigren_reseller_group;
    /**
     * @var
     */
    protected $tigren_reseller_group_customer;

    /**
     *
     */
    protected function _construct()
    {
        $this->_init('Tigren\Reseller\Model\ResellerGroup', 'Tigren\Reseller\Model\ResourceModel\ResellerGroup');
    }
}
