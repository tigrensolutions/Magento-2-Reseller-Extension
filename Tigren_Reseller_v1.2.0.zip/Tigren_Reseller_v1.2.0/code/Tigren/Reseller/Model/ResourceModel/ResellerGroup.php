<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Model\ResourceModel;

/**
 * Class ResellerGroup
 * @package Tigren\Reseller\Model\ResourceModel
 */
class ResellerGroup extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var string
     */
    protected $_groupCustomerTable;

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $_customer;

    /**
     * @var \Tigren\Reseller\Model\ResellerGroupFactory
     */
    protected $_resellerGroupFactory;

    /**
     * @var \Tigren\Reseller\Model\ResellerSubmittedFactory
     */
    protected $_customerSubmitFactory;

    /**
     * ResellerGroup constructor.
     * @param \Magento\Framework\Model\ResourceModel\Db\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Customer\Model\CustomerFactory $customer
     * @param \Tigren\Reseller\Model\ResellerGroupFactory $resellerGroupFactory
     * @param \Tigren\Reseller\Model\ResellerSubmittedFactory $customerSubmitFactory
     * @param null $resourcePrefix
     */
    public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Model\CustomerFactory $customer,
        \Tigren\Reseller\Model\ResellerGroupFactory $resellerGroupFactory,
        \Tigren\Reseller\Model\ResellerSubmittedFactory $customerSubmitFactory,
        $resourcePrefix = null
    ) {
        parent::__construct($context, $resourcePrefix);
        $this->_storeManager = $storeManager;
        $this->_groupCustomerTable = $this->getTable('tigren_reseller_group_customer');
        $this->_customer = $customer;
        $this->_resellerGroupFactory = $resellerGroupFactory;
        $this->_customerSubmitFactory = $customerSubmitFactory;
    }


    /**
     *
     */
    protected function _construct()
    {
        $this->_init('tigren_reseller_group', 'group_id');
    }

    /**
     * @param \Magento\Framework\Model\AbstractModel $object
     * @return $this|\Magento\Framework\Model\ResourceModel\Db\AbstractDb
     */
    protected function _afterLoad(\Magento\Framework\Model\AbstractModel $object)
    {
        parent::_afterLoad($object);

        if (!$object->getId()) {
            return $this;
        }

        $object->setCustomerGroup(explode(',', $object->getCustomerGroup()));
        $object->setCustomer($this->getCustomer((int)$object->getId()));

        return $this;
    }

    /**
     * @param $group_id
     * @return array
     */
    public function getCustomer($group_id)
    {
        $select = $this->getConnection()->select()->from(
            $this->getTable($this->_groupCustomerTable),
            'customer_id'
        )->where(
            'group_id = ?',
            $group_id
        );
        return $this->getConnection()->fetchCol($select);
    }

    /**
     * @param \Magento\Framework\Model\AbstractModel $object
     * @return \Magento\Framework\Model\ResourceModel\Db\AbstractDb|void
     */
    protected function _afterSave(\Magento\Framework\Model\AbstractModel $object)
    {
        $connection = $this->getConnection();
        $customerLevel = $object->getCustomerLevel();
        if (is_array($customerLevel)) {
            if ($customerLevel['action'] == \Tigren\Reseller\Model\ResellerGroup::ACTION_UPDATE_RESELLER_MEMBER) {
                $condition = ['customer_id = ?' => $customerLevel['customer_id']];
//                $connection->delete($this->_groupCustomerTable, $condition);
//                $groupInsert = [
//                    'group_id' => $customerLevel['level_up_group_id'],
//                    'customer_id' => $customerLevel['customer_id'],
//                    'base_customer_group' => $customerUpdateLevel->getGroupId()
//                ];
                $groupUpdate = [
                    'group_id' => $customerLevel['level_up_group_id']
                ];
//                $connection->insert($this->_groupCustomerTable, $groupInsert);
                $connection->update($this->_groupCustomerTable, $groupUpdate, $condition);
                $customerUpdateLevel = $this->_customer->create()->load($customerLevel['customer_id']);
                $groupReseller = $this->_resellerGroupFactory->create()->load($customerLevel['level_up_group_id']);
                if ($groupReseller->getId()) {
                    $customerUpdateLevel->setGroupId((string)($groupReseller->getCustomerGroup())[0])->save();
                }
            } elseif ($customerLevel['action'] == \Tigren\Reseller\Model\ResellerGroup::ACTION_DELETE_RESELLER_MEMBER) {
                $customerUpdateLevel = $this->_customer->create()->load($customerLevel['customer_id']);
                $customerUpdateLevel->setGroupId($this->getBaseCustomerGroup($customerLevel['customer_id']))->save();
                $condition = ['customer_id = ?' => $customerLevel['customer_id']];
                $connection->delete($this->_groupCustomerTable, $condition);
                $customerSubmitted = $this->_customerSubmitFactory->create()->loadByCustomerId($customerLevel['customer_id']);
                if ($customerSubmitted->getId()) {
                    $customerSubmitted->setStatus(0)->setResellerGroup(null)->save();
                }
            }
        }
    }

    /**
     * @param $customerId
     * @return string
     */
    protected function getBaseCustomerGroup($customerId)
    {
        $select = $this->getConnection()->select()->from(
            $this->getTable($this->_groupCustomerTable),
            'base_customer_group'
        )->where(
            'customer_id = ?',
            $customerId
        );
        return $this->getConnection()->fetchOne($select);
    }
}
