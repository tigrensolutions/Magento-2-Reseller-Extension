<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Model\ResourceModel;

use Magento\Framework\Model\AbstractModel;

/**
 * Class ResellerSubmitted
 * @package Tigren\Reseller\Model\ResourceModel
 */
class ResellerSubmitted extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var
     */
    protected $_groupCustomerTable;

    /**
     * @var \Tigren\Reseller\Model\ResellerGroupFactory
     */
    protected $_resellerGroupFactory;

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $_customer;

    /**
     * ResellerSubmitted constructor.
     * @param \Magento\Framework\Model\ResourceModel\Db\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Tigren\Reseller\Model\ResellerGroupFactory $resellerGroupFactory
     * @param \Magento\Customer\Model\CustomerFactory $customer
     * @param null $resourcePrefix
     */
    public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Tigren\Reseller\Model\ResellerGroupFactory $resellerGroupFactory,
        \Magento\Customer\Model\CustomerFactory $customer,
        $resourcePrefix = null
    ) {
        $this->_storeManager = $storeManager;
        $this->_resellerGroupFactory = $resellerGroupFactory;
        $this->_customer = $customer;
        parent::__construct($context, $resourcePrefix);
    }

    /**
     * @param \Tigren\Reseller\Model\ResellerSubmitted $resellerSubmitted
     * @param $customerId
     */
    public function loadByCustomerId(\Tigren\Reseller\Model\ResellerSubmitted $resellerSubmitted, $customerId)
    {
        $connection = $this->getConnection();
        $select = $connection->select()->from(
            'tigren_reseller_submitted',
            'submitted_id'
        )
            ->where("customer_id = {$customerId}");
        $submittedId = $connection->fetchOne($select);
        if ($submittedId) {
            $this->load($resellerSubmitted, $submittedId);
        } else {
            $resellerSubmitted->setData([]);
        }
    }

    /**
     *
     */
    protected function _construct()
    {
        $this->_init('tigren_reseller_submitted', 'submitted_id');
        $this->_groupCustomerTable = $this->getTable('tigren_reseller_group_customer');
    }

    /**
     * @param AbstractModel $object
     * @return $this|\Magento\Framework\Model\ResourceModel\Db\AbstractDb
     */
    protected function _afterLoad(AbstractModel $object)
    {
        parent::_afterLoad($object);

        if (!$object->getId()) {
            return $this;
        }

        $object->setResellerGroup($this->getResellerGroup((int)$object->getCustomerId()));

        return $this;
    }

    /**
     * @param $customerId
     * @return array
     */
    public function getResellerGroup($customerId)
    {
        $select = $this->getConnection()->select()->from(
            $this->getTable($this->_groupCustomerTable),
            'group_id'
        )->where(
            'customer_id = ?',
            $customerId
        );
        return $this->getConnection()->fetchCol($select);
    }

    /**
     * @param AbstractModel $object
     * @return \Magento\Framework\Model\ResourceModel\Db\AbstractDb|void
     */
    protected function _afterSave(\Magento\Framework\Model\AbstractModel $object)
    {
        $connection = $this->getConnection();
        $resellerGroup = $object->getResellerGroup();
        if (($resellerGroup) != '') {
            $condition = ['customer_id = ?' => $object->getCustomerId()];
            $connection->delete($this->_groupCustomerTable, $condition);

            $customerUpdate = $this->_customer->create()->load($object->getCustomerId());
            $groupInsert = [
                'group_id' => $resellerGroup,
                'customer_id' => $object->getCustomerId(),
                'base_customer_group' => $customerUpdate->getGroupId()
            ];
            $connection->insert($this->_groupCustomerTable, $groupInsert);
            $groupReseller = $this->_resellerGroupFactory->create()->load($resellerGroup);
            if ($groupReseller->getId()) {
                $customerUpdate->setGroupId((string)($groupReseller->getCustomerGroup())[0])->save();
            }
        } elseif ($resellerGroup == '') {
            $condition = ['customer_id = ?' => $object->getCustomerId()];
            $connection->delete($this->_groupCustomerTable, $condition);
        }
    }
}
