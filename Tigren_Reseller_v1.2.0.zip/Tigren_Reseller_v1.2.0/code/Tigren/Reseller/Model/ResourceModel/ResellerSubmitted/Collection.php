<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Model\ResourceModel\ResellerSubmitted;

/**
 * Class Collection
 * @package Tigren\Reseller\Model\ResourceModel\ResellerSubmitted
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     *
     */
    protected function _construct()
    {
        $this->_init('Tigren\Reseller\Model\ResellerSubmitted',
            'Tigren\Reseller\Model\ResourceModel\ResellerSubmitted');
    }
}
