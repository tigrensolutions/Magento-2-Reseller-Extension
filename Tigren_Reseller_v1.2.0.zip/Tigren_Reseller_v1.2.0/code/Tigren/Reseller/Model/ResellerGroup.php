<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Model;

/**
 * Class ResellerGroup
 * @package Tigren\Reseller\Model
 */
class ResellerGroup extends \Magento\Framework\Model\AbstractModel
{
    /**
     *
     */
    const ACTION_DELETE_RESELLER_MEMBER = 'delete_reseller_member';

    /**
     *
     */
    const ACTION_UPDATE_RESELLER_MEMBER = 'update_reseller_member';

    /**
     *
     */
    protected function _construct()
    {
        $this->_init('Tigren\Reseller\Model\ResourceModel\ResellerGroup');
    }

}