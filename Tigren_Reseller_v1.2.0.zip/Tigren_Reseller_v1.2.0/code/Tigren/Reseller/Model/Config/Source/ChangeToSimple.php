<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Model\Config\Source;

class ChangeToSimple implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Return array of options as value-label pairs, eg. value => label
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            '' => 'Select',
            '1' => '1 month',
            '2' => '2 months',
            '3' => '3 months',
            '4' => '4 months',
            '5' => '5 months',
            '6' => '6 months',
            '7' => '7 months',
            '8' => '8 months',
            '9' => '9 months',
            '10' => '10 months',
            '11' => '11 months',
            '12' => '12 months',
        ];
    }
}