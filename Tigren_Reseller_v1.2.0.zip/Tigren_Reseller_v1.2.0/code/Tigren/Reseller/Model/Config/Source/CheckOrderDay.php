<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Model\Config\Source;

class CheckOrderDay implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Return array of options as value-label pairs, eg. value => label
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            '' => 'Select',
            '5' => '5 days',
            '6' => '6 days',
            '7' => '7 days',
            '8' => '8 days',
            '9' => '9 days',
            '10' => '10 days',
        ];
    }
}