<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Model\Submitted\Source;

/**
 * Class HearAboutUs
 * @package Tigren\Reseller\Model\Submitted\Source
 */
class HearAboutUs implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [
            [
                'label' => 'Select',
                'value' => ''
            ],
            [
                'label' => 'Google',
                'value' => 'Google'
            ],
            [
                'label' => 'Bing',
                'value' => 'Bing'
            ],
            [
                'label' => 'Yahoo',
                'value' => 'Yahoo'
            ],
            [
                'label' => 'Facebook',
                'value' => 'Facebook'
            ],
            [
                'label' => 'Word of mouth',
                'value' => 'Word of mouth'
            ],
            [
                'label' => 'Other',
                'value' => 'Other'
            ]
        ];

        return $options;
    }
}
