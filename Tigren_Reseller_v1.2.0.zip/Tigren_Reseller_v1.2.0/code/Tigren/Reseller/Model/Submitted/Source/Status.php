<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Model\Submitted\Source;

/**
 * Class Status
 * @package Tigren\Reseller\Model\Submitted\Source
 */
class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     *
     */
    const SUBMITTED_PENDING = 0;

    /**
     *
     */
    const SUBMITTED_APPROVED = 1;

    /**
     *
     */
    const SUBMITTED_REJECTED = 2;

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [
            [
                'label' => '',
                'value' => ''
            ],
            [
                'label' => 'Pending',
                'value' => '0'
            ],
            [
                'label' => 'Approved',
                'value' => '1'
            ],
            [
                'label' => 'Rejected',
                'value' => '2'
            ]
        ];

        return $options;
    }
}
