<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Model;

/**
 * Class ResellerSubmitted
 * @package Tigren\Reseller\Model
 */
class ResellerSubmitted extends \Magento\Framework\Model\AbstractModel
{
    /**
     * @param $customerId
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function loadByCustomerId($customerId)
    {
        $this->_getResource()->loadByCustomerId($this, $customerId);
        return $this;
    }

    /**
     *
     */
    protected function _construct()
    {
        $this->_init('Tigren\Reseller\Model\ResourceModel\ResellerSubmitted');
    }
}