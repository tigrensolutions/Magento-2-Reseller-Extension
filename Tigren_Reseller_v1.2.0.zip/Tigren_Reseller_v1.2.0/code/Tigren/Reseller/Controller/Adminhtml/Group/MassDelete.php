<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Controller\Adminhtml\Group;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\View\Result\PageFactory;

/**
 * Class MassDelete
 * @package Tigren\Reseller\Controller\Adminhtml\Group
 */
class MassDelete extends \Magento\Backend\App\Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var \Magento\Ui\Component\MassAction\Filter
     */
    protected $_massActionFilter;

    /**
     * @var \Tigren\Reseller\Model\ResellerGroupFactory
     */
    protected $_resellerGroupFactory;

    /**
     * @var \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory
     */
    protected $_resellerGroupCollectionFactory;

    /**
     * MassDelete constructor.
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param \Magento\Ui\Component\MassAction\Filter $massActionFilter
     * @param \Tigren\Reseller\Model\ResellerGroupFactory $resellerGroupFactory
     * @param \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory $resellerGroupCollectionFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        \Magento\Ui\Component\MassAction\Filter $massActionFilter,
        \Tigren\Reseller\Model\ResellerGroupFactory $resellerGroupFactory,
        \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory $resellerGroupCollectionFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->_massActionFilter = $massActionFilter;
        $this->_resellerGroupFactory = $resellerGroupFactory;
        $this->_resellerGroupCollectionFactory = $resellerGroupCollectionFactory;
    }

    /**
     * @return \Magento\Backend\Model\View\Result\Redirect|\Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $idsSelected = $this->getRequest()->getParam('selected');
        $collection = $this->_resellerGroupCollectionFactory->create()->addFieldToFilter('group_id',
            ['in' => $idsSelected]);
        $collectionSize = $collection->getSize();

        foreach ($collection->getItems() as $item) {
            $resellerGroup = $this->_resellerGroupFactory->create()->setId($item->getData('group_id'));
            $resellerGroup->delete();
        }

        $this->messageManager->addSuccess(__('A total of %1 element(s) have been deleted.', $collectionSize));

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('*/*/');
    }
}
