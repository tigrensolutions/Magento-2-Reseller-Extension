<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Controller\Adminhtml\Group;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

/**
 * Class Delete
 * @package Tigren\Reseller\Controller\Adminhtml\Group
 */
class Delete extends \Magento\Backend\App\Action
{
    /**
     * @var PageFactory
     */
    protected $_resultPageFactory;
    /**
     * @var \Tigren\Reseller\Model\ResellerGroupFactory
     */
    protected $_resellerGroupFactory;

    /**
     * Delete constructor.
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param \Tigren\Reseller\Model\ResellerGroupFactory $resellerGroupFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        \Tigren\Reseller\Model\ResellerGroupFactory $resellerGroupFactory
    ) {
        parent::__construct($context);
        $this->_resultPageFactory = $resultPageFactory;
        $this->_resellerGroupFactory = $resellerGroupFactory;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $groupId = $this->getRequest()->getParam('group_id');
        try {
            $resellerGroup = $this->_resellerGroupFactory->create()->setId($groupId);
            $resellerGroup->delete();
            $this->messageManager->addSuccess(
                __('Delete successfully !')
            );
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        $resultRedirect = $this->resultRedirectFactory->create();

        return $resultRedirect->setPath('*/*/');
    }
}
