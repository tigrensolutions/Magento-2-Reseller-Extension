<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Controller\Adminhtml\Submitted;

use Magento\Backend\App\Action;

/**
 * Class Save
 * @package Tigren\Reseller\Controller\Adminhtml\Submitted
 */
class Save extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\App\Cache\TypeListInterface
     */
    protected $cacheTypeList;

    /**
     * @var \Magento\Backend\Helper\Js
     */
    protected $jsHelper;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_datetime;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * @var \Tigren\Reseller\Helper\Email
     */
    protected $_resellerEmailHelper;

    /**
     * @var \Tigren\Reseller\Helper\Data
     */
    protected $_resellerHelper;

    /**
     * @var \Magento\Customer\Api\CustomerRepositoryInterface
     */
    protected $_customerRepositoryInterface;

    /**
     * Save constructor.
     * @param Action\Context $context
     * @param \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList
     * @param \Magento\Backend\Helper\Js $jsHelper
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
     * @param \Magento\Framework\Registry $registry
     * @param \Tigren\Reseller\Helper\Email $resellerEmailHelper
     * @param \Tigren\Reseller\Helper\Data $resellerHelper
     * @param \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface
     */
    public function __construct(
        Action\Context $context,
        \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList,
        \Magento\Backend\Helper\Js $jsHelper,
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTime,
        \Magento\Framework\Registry $registry,
        \Tigren\Reseller\Helper\Email $resellerEmailHelper,
        \Tigren\Reseller\Helper\Data $resellerHelper,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface
    ) {
        $this->cacheTypeList = $cacheTypeList;
        parent::__construct($context);
        $this->jsHelper = $jsHelper;
        $this->_datetime = $dateTime;
        $this->_coreRegistry = $registry;
        $this->_resellerEmailHelper = $resellerEmailHelper;
        $this->_resellerHelper = $resellerHelper;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
    }

    /**
     * @return \Magento\Backend\Model\View\Result\Redirect|\Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($data) {
            /** @var \Tigren\Reseller\Model\ResellerSubmitted $model */
            $model = $this->_objectManager->create('Tigren\Reseller\Model\ResellerSubmitted');

            $id = $data['submitted_id'];
            if ($id) {
                $model->load($id);
            }

            $model->setStatus($data['status']);
            $model->setResellerGroup($data['reseller_group']);

            try {
                $model->save();
                $this->cacheTypeList->invalidate('full_page');
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                try {
                    if ($data['status'] != \Tigren\Reseller\Model\Submitted\Source\Status::SUBMITTED_PENDING) {
                        if ($data['status'] == \Tigren\Reseller\Model\Submitted\Source\Status::SUBMITTED_APPROVED) {
                            $templateEmail = $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::RESELLER_APPROVE_SUBMITTED_EMAIL_TEMPLATE);
                        } elseif ($data['status'] == \Tigren\Reseller\Model\Submitted\Source\Status::SUBMITTED_REJECTED) {
                            $templateEmail = $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::RESELLER_DECLINE_SUBMITTED_EMAIL_TEMPLATE);
                        }
                        $customer = $this->_customerRepositoryInterface->getById($data['customer_id']);
                        //send email to customer
                        $this->_resellerEmailHelper->resellerSendEmail(
                            $templateEmail,
                            [],
                            $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::XML_PATH_SENDER_EMAIL),
                            $customer->getEmail()
                        );
                    }
                    $this->messageManager->addSuccess(__('You saved this Submitted.'));
                    $resultRedirect->setPath('*/*/');
                } catch (\Exception $e) {
                    $this->messageManager->addError($e->getMessage());
                    return $resultRedirect->setPath('*/*/');
                }
                return $resultRedirect;
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the group.'));
            }

            $this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('*/*/edit',
                ['submitted_id' => $this->getRequest()->getParam('submitted_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Reseller::submitted');
    }
}
