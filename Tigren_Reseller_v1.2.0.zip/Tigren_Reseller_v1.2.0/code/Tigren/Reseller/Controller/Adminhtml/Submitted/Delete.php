<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Controller\Adminhtml\Submitted;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

/**
 * Class Delete
 * @package Tigren\Reseller\Controller\Adminhtml\Submitted
 */
class Delete extends \Magento\Backend\App\Action
{
    /**
     * @var PageFactory
     */
    protected $_resultPageFactory;
    /**
     * @var \Tigren\Reseller\Model\ResellerSubmittedFactory
     */
    protected $_resellerSubmittedFactory;

    /**
     * Delete constructor.
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param \Tigren\Reseller\Model\ResellerSubmittedFactory $resellerSubmittedFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        \Tigren\Reseller\Model\ResellerSubmittedFactory $resellerSubmittedFactory
    ) {
        parent::__construct($context);
        $this->_resultPageFactory = $resultPageFactory;
        $this->_resellerSubmittedFactory = $resellerSubmittedFactory;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $submittedId = $this->getRequest()->getParam('submitted_id');
        try {
            $resellerSubmitted = $this->_resellerSubmittedFactory->create()->setId($submittedId);
            $resellerSubmitted->delete();
            $this->messageManager->addSuccess(
                __('Delete successfully !')
            );
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        $resultRedirect = $this->resultRedirectFactory->create();

        return $resultRedirect->setPath('*/*/');
    }
}