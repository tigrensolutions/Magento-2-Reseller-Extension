<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Controller\Adminhtml\Submitted;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\View\Result\PageFactory;

/**
 * Class MassDelete
 * @package Tigren\Reseller\Controller\Adminhtml\Submitted
 */
class MassDelete extends \Magento\Backend\App\Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var \Magento\Ui\Component\MassAction\Filter
     */
    protected $_massActionFilter;

    /**
     * @var \Tigren\Reseller\Model\ResellerSubmittedFactory
     */
    protected $_resellerSubmittedFactory;

    /**
     * @var \Tigren\Reseller\Model\ResourceModel\ResellerSubmitted\CollectionFactory
     */
    protected $_resellerSubmittedCollectionFactory;

    /**
     * MassDelete constructor.
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param \Magento\Ui\Component\MassAction\Filter $massActionFilter
     * @param \Tigren\Reseller\Model\ResellerSubmittedFactory $resellerSubmittedFactory
     * @param \Tigren\Reseller\Model\ResourceModel\ResellerSubmitted\CollectionFactory $resellerSubmittedCollectionFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        \Magento\Ui\Component\MassAction\Filter $massActionFilter,
        \Tigren\Reseller\Model\ResellerSubmittedFactory $resellerSubmittedFactory,
        \Tigren\Reseller\Model\ResourceModel\ResellerSubmitted\CollectionFactory $resellerSubmittedCollectionFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->_massActionFilter = $massActionFilter;
        $this->_resellerSubmittedFactory = $resellerSubmittedFactory;
        $this->_resellerSubmittedCollectionFactory = $resellerSubmittedCollectionFactory;
    }

    /**
     * @return \Magento\Backend\Model\View\Result\Redirect|\Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
        $collection = $this->_massActionFilter->getCollection($this->_resellerSubmittedCollectionFactory->create());
        $collectionSize = $collection->getSize();

        foreach ($collection->getItems() as $item) {
            $resellerSubmitted = $this->_resellerSubmittedFactory->create()->setId($item->getData('submitted_id'));
            $resellerSubmitted->delete();
        }

        $this->messageManager->addSuccess(__('A total of %1 element(s) have been deleted.', $collectionSize));

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('*/*/');
    }
}
