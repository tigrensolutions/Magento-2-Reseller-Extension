<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Controller\Index;

use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Api\Data\AddressInterfaceFactory;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;
use Magento\Customer\Api\Data\RegionInterfaceFactory;
use Magento\Customer\Helper\Address;
use Magento\Customer\Model\Account\Redirect as AccountRedirect;
use Magento\Customer\Model\CustomerExtractor;
use Magento\Customer\Model\Metadata\FormFactory;
use Magento\Customer\Model\Registration;
use Magento\Customer\Model\Session;
use Magento\Customer\Model\Url as CustomerUrl;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Escaper;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\UrlFactory;
use Magento\Newsletter\Model\SubscriberFactory;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class Save
 * @package Tigren\Reseller\Controller\Index
 */
class Save extends Action
{
    //variable of customer create post controller
    /**
     * @var AccountManagementInterface
     */
    protected $accountManagement;

    /**
     * @var Address
     */
    protected $addressHelper;

    /**
     * @var FormFactory
     */
    protected $formFactory;

    /**
     * @var SubscriberFactory
     */
    protected $subscriberFactory;

    /**
     * @var RegionInterfaceFactory
     */
    protected $regionDataFactory;

    /**
     * @var AddressInterfaceFactory
     */
    protected $addressDataFactory;

    /**
     * @var Registration
     */
    protected $registration;

    /**
     * @var CustomerInterfaceFactory
     */
    protected $customerDataFactory;

    /**
     * @var CustomerUrl
     */
    protected $customerUrl;

    /**
     * @var Escaper
     */
    protected $escaper;

    /**
     * @var CustomerExtractor
     */
    protected $customerExtractor;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlModel;

    /**
     * @var DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * @var Session
     */
    protected $session;

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_datetime;

    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;

    /**
     * @var \Magento\Framework\Translate\Inline\StateInterface
     */
    protected $_inlineTranslation;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var \Tigren\Reseller\Helper\Data
     */
    protected $_resellerHelper;

    /**
     * @var \Tigren\Reseller\Helper\Email
     */
    protected $_resellerEmailHelper;

    /**
     * @var \Magento\Directory\Model\CountryFactory
     */
    protected $_countryFactory;

    /**
     * @var \Magento\Directory\Model\RegionFactory
     */
    protected $_regionFactory;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $_jsonHelper;

    /**
     * @var AccountRedirect
     */
    private $accountRedirect;

    /**
     * @var
     */
    private $cookieMetadataFactory;

    /**
     * @var
     */
    private $cookieMetadataManager;

    /**
     * @var mixed
     */
    private $formKeyValidator;

    /**
     * Save constructor.
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Tigren\Reseller\Helper\Data $resellerHelper
     * @param \Tigren\Reseller\Helper\Email $resellerEmailHelper
     * @param Session $customerSession
     * @param StoreManagerInterface $storeManager
     * @param AccountManagementInterface $accountManagement
     * @param Address $addressHelper
     * @param UrlFactory $urlFactory
     * @param FormFactory $formFactory
     * @param SubscriberFactory $subscriberFactory
     * @param RegionInterfaceFactory $regionDataFactory
     * @param AddressInterfaceFactory $addressDataFactory
     * @param CustomerInterfaceFactory $customerDataFactory
     * @param CustomerUrl $customerUrl
     * @param Registration $registration
     * @param Escaper $escaper
     * @param CustomerExtractor $customerExtractor
     * @param DataObjectHelper $dataObjectHelper
     * @param AccountRedirect $accountRedirect
     * @param Validator|null $formKeyValidator
     * @param \Magento\Directory\Model\CountryFactory $countryFactory
     * @param \Magento\Directory\Model\RegionFactory $regionFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTime,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Tigren\Reseller\Helper\Data $resellerHelper,
        \Tigren\Reseller\Helper\Email $resellerEmailHelper,
        Session $customerSession,
        StoreManagerInterface $storeManager,
        AccountManagementInterface $accountManagement,
        Address $addressHelper,
        UrlFactory $urlFactory,
        FormFactory $formFactory,
        SubscriberFactory $subscriberFactory,
        RegionInterfaceFactory $regionDataFactory,
        AddressInterfaceFactory $addressDataFactory,
        CustomerInterfaceFactory $customerDataFactory,
        CustomerUrl $customerUrl,
        Registration $registration,
        Escaper $escaper,
        CustomerExtractor $customerExtractor,
        DataObjectHelper $dataObjectHelper,
        AccountRedirect $accountRedirect,
        Validator $formKeyValidator = null,
        \Magento\Directory\Model\CountryFactory $countryFactory,
        \Magento\Directory\Model\RegionFactory $regionFactory,
        \Magento\Framework\Json\Helper\Data $jsonHelper
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->_datetime = $dateTime;
        $this->_transportBuilder = $transportBuilder;
        $this->_inlineTranslation = $inlineTranslation;
        $this->_scopeConfig = $scopeConfig;
        $this->_resellerHelper = $resellerHelper;
        $this->_resellerEmailHelper = $resellerEmailHelper;
        $this->session = $customerSession;
        $this->storeManager = $storeManager;
        $this->accountManagement = $accountManagement;
        $this->addressHelper = $addressHelper;
        $this->formFactory = $formFactory;
        $this->subscriberFactory = $subscriberFactory;
        $this->regionDataFactory = $regionDataFactory;
        $this->addressDataFactory = $addressDataFactory;
        $this->customerDataFactory = $customerDataFactory;
        $this->customerUrl = $customerUrl;
        $this->registration = $registration;
        $this->escaper = $escaper;
        $this->customerExtractor = $customerExtractor;
        $this->urlModel = $urlFactory->create();
        $this->dataObjectHelper = $dataObjectHelper;
        $this->accountRedirect = $accountRedirect;
        $this->formKeyValidator = $formKeyValidator ?: ObjectManager::getInstance()->get(Validator::class);
        $this->_countryFactory = $countryFactory;
        $this->_regionFactory = $regionFactory;
        $this->_jsonHelper = $jsonHelper;

        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Forward|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if (!$this->session->isLoggedIn()) {
            if (!$this->getRequest()->isPost() || !$this->formKeyValidator->validate($this->getRequest())) {
                $url = $this->urlModel->getUrl('reseller/index/index', ['_secure' => true]);
                $resultRedirect->setUrl($this->_redirect->error($url));
                return $resultRedirect;
            }

            $this->session->regenerateId();

            try {
                $address = $this->extractAddress();
                $addresses = $address === null ? [] : [$address];

                $customer = $this->customerExtractor->extract('customer_account_create', $this->_request);
                // $customer->setAddresses($addresses);

                $password = $this->getRequest()->getParam('password');
                $confirmation = $this->getRequest()->getParam('password_confirmation');
                $redirectUrl = $this->session->getBeforeAuthUrl();

                $this->checkPasswordConfirmation($password, $confirmation);

                $customer = $this->accountManagement
                    ->createAccount($customer, $password, $redirectUrl);

                if ($this->getRequest()->getParam('is_subscribed', false)) {
                    $this->subscriberFactory->create()->subscribeCustomerById($customer->getId());
                }

                $this->_eventManager->dispatch(
                    'customer_register_success',
                    ['account_controller' => $this, 'customer' => $customer]
                );

                $confirmationStatus = $this->accountManagement->getConfirmationStatus($customer->getId());
                if ($confirmationStatus === AccountManagementInterface::ACCOUNT_CONFIRMATION_REQUIRED) {
                    $email = $this->customerUrl->getEmailConfirmationUrl($customer->getEmail());
                    // @codingStandardsIgnoreStart
                    $this->messageManager->addSuccess(
                        __(
                            'You must confirm your account. Please check your email for the confirmation link or <a href="%1">click here</a> for a new link.',
                            $email
                        )
                    );
                    // @codingStandardsIgnoreEnd
                    $url = $this->urlModel->getUrl('*/*/index', ['_secure' => true]);
                    $resultRedirect->setUrl($this->_redirect->success($url));
                } else {
                    $this->session->setCustomerDataAsLoggedIn($customer);
                    $this->messageManager->addSuccess($this->getSuccessMessage());
                    $requestedRedirect = $this->accountRedirect->getRedirectCookie();
                    if (!$this->_scopeConfig->getValue('customer/startup/redirect_dashboard') && $requestedRedirect) {
                        $resultRedirect->setUrl($this->_redirect->success($requestedRedirect));
                        $this->accountRedirect->clearRedirectCookie();
                        return $resultRedirect;
                    }
                    $resultRedirect = $this->accountRedirect->getRedirect();
                }
                if ($this->getCookieManager()->getCookie('mage-cache-sessid')) {
                    $metadata = $this->getCookieMetadataFactory()->createCookieMetadata();
                    $metadata->setPath('/');
                    $this->getCookieManager()->deleteCookie('mage-cache-sessid', $metadata);
                }

                //save submitted
                try {
                    $data = $this->getRequest()->getPostValue();
                    $model = $this->_objectManager->create('Tigren\Reseller\Model\ResellerSubmitted');
                    $model->setData($data);
                    $model->setCustomerId($customer->getId());
                    $model->setCustomerEmail($customer->getEmail());

                    if (!empty($data['answer'])) {
                        $model->setAnswer($this->_jsonHelper->jsonEncode($data['answer']));
                    }

                    $model->setCreatedAt($this->_datetime->gmtDate());
                    $model->setCountry($this->_countryFactory->create()->loadByCode($data['country_id'])->getName());
                    if (isset($data['region_id'])) {
                        $model->setState($this->_regionFactory->create()->load($data['region_id'])->getName());
                    } else {
                        $model->setState($data['region']);
                    }
                    $model->setAddress1($data['address'][0]);
                    $model->setAddress2($data['address'][1]);
                    $model->save();
                    try {
                        //send email to customer
                        $this->_resellerEmailHelper->resellerSendEmail(
                            $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::RESELLER_REVIEW_STATUS_EMAIL_TEMPLATE),
                            [],
                            $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::XML_PATH_SENDER_EMAIL),
                            $customer->getEmail()
                        );
                        //send email to sales team
                        $this->_resellerEmailHelper->resellerSendEmail(
                            $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::RESELLER_REQUEST_SUBMITTED_EMAIL_TEMPLATE),
                            [],
                            $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::XML_PATH_SENDER_EMAIL),
                            $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::XML_PATH_SEND_EMAIL_TO)
                        );
                        $resultRedirect->setPath('customer/account/');
                    } catch (\Exception $e) {
                        $this->messageManager->addError($e->getMessage());
                        $this->messageManager->addException($e, __("Can't send email submitted"));
                    }
                } catch (\Exception $e) {
                    $this->messageManager->addError($e->getMessage());
                    $this->messageManager->addException($e, __('Something went wrong while saving the row.'));
                }

                return $resultRedirect;
            } catch (StateException $e) {
                $url = $this->urlModel->getUrl('reseller/index/index');
                // @codingStandardsIgnoreStart
                $message = __(
                    'There is already an account with this email address. If you are sure that it is your email address, <a href="%1">click here</a> to get your password and access your account.',
                    $url
                );
                // @codingStandardsIgnoreEnd
                $this->messageManager->addError($message);
            } catch (InputException $e) {
                $this->messageManager->addError($this->escaper->escapeHtml($e->getMessage()));
                foreach ($e->getErrors() as $error) {
                    $this->messageManager->addError($this->escaper->escapeHtml($error->getMessage()));
                }
            } catch (LocalizedException $e) {
                $this->messageManager->addError($this->escaper->escapeHtml($e->getMessage()));
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('We can\'t save the customer.'));
            }
        } else {
            //save submitted
            try {
                $data = $this->getRequest()->getPostValue();
                $model = $this->_objectManager->create('Tigren\Reseller\Model\ResellerSubmitted');
                $model->setData($data);
                $model->setCustomerId($this->session->getCustomerId());
                $model->setCustomerEmail($this->session->getCustomer()->getEmail());

                if (!empty($data['answer'])) {
                    $model->setAnswer($this->_jsonHelper->jsonEncode($data['answer']));
                }

                $model->setCreatedAt($this->_datetime->gmtDate());
                $model->setCountry($this->_countryFactory->create()->loadByCode($data['country_id'])->getName());
                if (isset($data['region_id'])) {
                    $model->setState($this->_regionFactory->create()->load($data['region_id'])->getName());
                } else {
                    $model->setState($data['region']);
                }
                $model->setAddress1($data['address'][0]);
                $model->setAddress2($data['address'][1]);
                $model->save();
                try {
                    //send email to customer
                    $this->_resellerEmailHelper->resellerSendEmail(
                        $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::RESELLER_REQUEST_SUBMITTED_EMAIL_TEMPLATE),
                        [],
                        $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::XML_PATH_SENDER_EMAIL),
                        $this->session->getCustomer()->getEmail()
                    );
                    //send email to sales team
                    $this->_resellerEmailHelper->resellerSendEmail(
                        $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::RESELLER_REQUEST_SUBMITTED_EMAIL_TEMPLATE),
                        [],
                        $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::XML_PATH_SENDER_EMAIL),
                        $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::XML_PATH_SEND_EMAIL_TO)
                    );
                    $this->messageManager->addSuccess(__('Thank you for your request. We will get back to you shortly.'));
                    $resultRedirect->setPath('customer/account/');
                } catch (\Exception $e) {
                    $this->messageManager->addError($e->getMessage());
                    $this->messageManager->addException($e, __("Can't send email submitted"));
                }
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
                $this->messageManager->addException($e, __('Something went wrong while saving the row.'));
            }
            return $resultRedirect;
        }

        $this->session->setCustomerFormData($this->getRequest()->getPostValue());
        $defaultUrl = $this->urlModel->getUrl('reseller/index/index', ['_secure' => true]);
        $resultRedirect->setUrl($this->_redirect->error($defaultUrl));
        return $resultRedirect;
    }

    /**
     * @return null
     */
    protected function extractAddress()
    {
        if (!$this->getRequest()->getPost('create_address')) {
            return null;
        }

        $addressForm = $this->formFactory->create('customer_address', 'customer_register_address');
        $allowedAttributes = $addressForm->getAllowedAttributes();

        $addressData = [];

        $regionDataObject = $this->regionDataFactory->create();
        foreach ($allowedAttributes as $attribute) {
            $attributeCode = $attribute->getAttributeCode();
            $value = $this->getRequest()->getParam($attributeCode);
            if ($value === null) {
                continue;
            }
            switch ($attributeCode) {
                case 'region_id':
                    $regionDataObject->setRegionId($value);
                    break;
                case 'region':
                    $regionDataObject->setRegion($value);
                    break;
                default:
                    $addressData[$attributeCode] = $value;
            }
        }
        $addressDataObject = $this->addressDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $addressDataObject,
            $addressData,
            \Magento\Customer\Api\Data\AddressInterface::class
        );
        $addressDataObject->setRegion($regionDataObject);

        $addressDataObject->setIsDefaultBilling(
            $this->getRequest()->getParam('default_billing', false)
        )->setIsDefaultShipping(
            $this->getRequest()->getParam('default_shipping', false)
        );
        return $addressDataObject;
    }

    /**
     * @param $password
     * @param $confirmation
     * @throws InputException
     */
    protected function checkPasswordConfirmation($password, $confirmation)
    {
        if ($password != $confirmation) {
            throw new InputException(__('Please make sure your passwords match.'));
        }
    }

    /**
     * @return \Magento\Framework\Phrase
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getSuccessMessage()
    {
        if ($this->addressHelper->isVatValidationEnabled()) {
            if ($this->addressHelper->getTaxCalculationAddressType() == Address::TYPE_SHIPPING) {
                // @codingStandardsIgnoreStart
                $message = __(
                    'If you are a registered VAT customer, please <a href="%1">click here</a> to enter your shipping address for proper VAT calculation.',
                    $this->urlModel->getUrl('customer/address/edit')
                );
                // @codingStandardsIgnoreEnd
            } else {
                // @codingStandardsIgnoreStart
                $message = __(
                    'If you are a registered VAT customer, please <a href="%1">click here</a> to enter your billing address for proper VAT calculation.',
                    $this->urlModel->getUrl('customer/address/edit')
                );
                // @codingStandardsIgnoreEnd
            }
        } else {
            $message = __('Thank you for registering with %1.', $this->storeManager->getStore()->getFrontendName());
        }
        return $message;
    }

    /**
     * @return mixed
     */
    private function getCookieManager()
    {
        if (!$this->cookieMetadataManager) {
            $this->cookieMetadataManager = ObjectManager::getInstance()->get(
                \Magento\Framework\Stdlib\Cookie\PhpCookieManager::class
            );
        }
        return $this->cookieMetadataManager;
    }

    /**
     * @return mixed
     */
    private function getCookieMetadataFactory()
    {
        if (!$this->cookieMetadataFactory) {
            $this->cookieMetadataFactory = ObjectManager::getInstance()->get(
                \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory::class
            );
        }
        return $this->cookieMetadataFactory;
    }
}
