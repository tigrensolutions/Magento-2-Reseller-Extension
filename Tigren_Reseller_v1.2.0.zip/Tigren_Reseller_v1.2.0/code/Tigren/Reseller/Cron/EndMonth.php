<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Cron;

/**
 * Class EndMonth
 * @package Tigren\Reseller\Cron
 */
class EndMonth
{
    /**
     * @var
     */
    protected $_scopeConfig;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_dateTime;

    /**
     * @var \Magento\Reports\Model\ResourceModel\Order\Collection
     */
    protected $_reportOrderCollectionFactory;

    /**
     * @var \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory
     */
    protected $_resellerGroupCollectionFactory;

    /**
     * @var \Tigren\Reseller\Model\ResellerGroupFactory
     */
    protected $_resellerGroupFactory;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $_logger;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_sessionCustomer;

    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @var \Tigren\Reseller\Helper\Email
     */
    protected $_resellerEmailHelper;

    /**
     * @var \Tigren\Reseller\Helper\Data
     */
    protected $_resellerHelper;

    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\CollectionFactory
     */
    protected $_orderCollectionFactory;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    protected $_timeZone;

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $_customerFactory;

    /**
     * EndMonth constructor.
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
     * @param \Magento\Reports\Model\ResourceModel\Order\Collection $reportOrderCollectionFactory
     * @param \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory $resellerGroupCollectionFactory
     * @param \Tigren\Reseller\Model\ResellerGroupFactory $resellerGroupFactory
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Customer\Model\Session $sessionCustomer
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Tigren\Reseller\Helper\Email $resellerEmailHelper
     * @param \Tigren\Reseller\Helper\Data $resellerHelper
     * @param \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTime,
        \Magento\Reports\Model\ResourceModel\Order\Collection $reportOrderCollectionFactory,
        \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory $resellerGroupCollectionFactory,
        \Tigren\Reseller\Model\ResellerGroupFactory $resellerGroupFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Customer\Model\Session $sessionCustomer,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Tigren\Reseller\Helper\Email $resellerEmailHelper,
        \Tigren\Reseller\Helper\Data $resellerHelper,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Magento\Customer\Model\CustomerFactory $customerFactory
    ) {
        $this->_dateTime = $dateTime;
        $this->_reportOrderCollectionFactory = $reportOrderCollectionFactory;
        $this->_resellerGroupCollectionFactory = $resellerGroupCollectionFactory;
        $this->_resellerGroupFactory = $resellerGroupFactory;
        $this->_logger = $logger;
        $this->_sessionCustomer = $sessionCustomer;
        $this->_objectManager = $objectManager;
        $this->_resellerEmailHelper = $resellerEmailHelper;
        $this->_resellerHelper = $resellerHelper;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->_timeZone = $timezone;
        $this->_customerFactory = $customerFactory;
    }

    /**
     *
     */
    public function execute()
    {
        $dataOrderCustomers = $this->_reportOrderCollectionFactory
            ->joinCustomerName()
            ->groupByCustomer()
            ->addOrdersCount()
            ->addSumAvgTotals()
            ->addFieldToFilter('status', 'complete')
            ->addFieldToFilter(
                'created_at',
                [
                    'from' => $this->_timeZone->date($this->_dateTime->gmtDate())->format('Y-m-01'),
                    'to' => $this->_timeZone->date($this->_dateTime->gmtDate())->format('Y-m-d H:i:s')
                ]
            );
        $resellerGroups = $this->_resellerGroupCollectionFactory->create()->setOrder('group_rank', 'asc');

        $configCheckBeforeDay = $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Data::XML_PATH_CHECK_ORDER_DAY);
        if ((int)$configCheckBeforeDay > 0 && $this->checkSuccessDay() == (int)$configCheckBeforeDay) {
            if ($dataOrderCustomers->count()) {
                foreach ($resellerGroups as $resellerGroup) {
                    $customDataOfReseller = $this->_resellerGroupFactory->create()->load($resellerGroup->getId());
                    $customersOfGroup = $customDataOfReseller->getCustomer();
                    //check is reseller and update reseller member
                    foreach ($dataOrderCustomers as $dataOrderCustomer) {
                        if (in_array($dataOrderCustomer->getCustomerId(), $customersOfGroup)) {
                            //check total orders before end month.
                            if ($dataOrderCustomer->getOrdersSumAmount() < $resellerGroup->getMinimumSpentOfMonth()) {
                                try {
                                    $this->_resellerEmailHelper->resellerSendEmail(
                                        $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::RESELLER_MARKETING_EMAIL_TEMPLATE),
                                        [],
                                        $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::XML_PATH_SENDER_EMAIL),
                                        $dataOrderCustomer->getCustomerEmail()
                                    );
                                    $this->_logger->alert('Reseller Module: Send email to reseller before end month!');
                                } catch (\Exception $e) {
                                    $this->_logger->error("Reseller Module: Can't send email before end month! " . $e->getMessage());
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @return string
     */
    public function checkSuccessDay()
    {
        $lastDay = $this->_timeZone->date($this->_dateTime->gmtDate())->format('t');
        $today = $this->_timeZone->date($this->_dateTime->gmtDate())->format('d');
        return $lastDay - $today;
    }
}
