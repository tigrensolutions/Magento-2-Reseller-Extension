<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Cron;

/**
 * Class OrderTotalsCustomer
 * @package Tigren\Reseller\Cron
 */
class OrderTotalsCustomer
{
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_dateTime;

    /**
     * @var \Magento\Reports\Model\ResourceModel\Order\Collection
     */
    protected $_reportOrderCollectionFactory;

    /**
     * @var \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory
     */
    protected $_resellerGroupCollectionFactory;

    /**
     * @var \Tigren\Reseller\Model\ResellerGroupFactory
     */
    protected $_resellerGroupFactory;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $_logger;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_sessionCustomer;

    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @var \Tigren\Reseller\Helper\Email
     */
    protected $_resellerEmailHelper;

    /**
     * @var \Tigren\Reseller\Helper\Data
     */
    protected $_resellerHelper;

    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\CollectionFactory
     */
    protected $_orderCollectionFactory;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    protected $_timeZone;

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $_customerFactory;

    /**
     * @var int
     */
    protected $_configTimeForDemotionConsideration = 3;

    /**
     * OrderTotalsCustomer constructor.
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
     * @param \Magento\Reports\Model\ResourceModel\Order\Collection $reportOrderCollectionFactory
     * @param \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory $resellerGroupCollectionFactory
     * @param \Tigren\Reseller\Model\ResellerGroupFactory $resellerGroupFactory
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Customer\Model\Session $sessionCustomer
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Tigren\Reseller\Helper\Email $resellerEmailHelper
     * @param \Tigren\Reseller\Helper\Data $resellerHelper
     * @param \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTime,
        \Magento\Reports\Model\ResourceModel\Order\Collection $reportOrderCollectionFactory,
        \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory $resellerGroupCollectionFactory,
        \Tigren\Reseller\Model\ResellerGroupFactory $resellerGroupFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Customer\Model\Session $sessionCustomer,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Tigren\Reseller\Helper\Email $resellerEmailHelper,
        \Tigren\Reseller\Helper\Data $resellerHelper,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Magento\Customer\Model\CustomerFactory $customerFactory
    ) {
        $this->_scopeConfig = $scopeConfig;
        $this->_dateTime = $dateTime;
        $this->_reportOrderCollectionFactory = $reportOrderCollectionFactory;
        $this->_resellerGroupCollectionFactory = $resellerGroupCollectionFactory;
        $this->_resellerGroupFactory = $resellerGroupFactory;
        $this->_logger = $logger;
        $this->_sessionCustomer = $sessionCustomer;
        $this->_objectManager = $objectManager;
        $this->_resellerEmailHelper = $resellerEmailHelper;
        $this->_resellerHelper = $resellerHelper;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->_timeZone = $timezone;
        $this->_customerFactory = $customerFactory;
    }

    /**
     *
     */
    public function execute()
    {
        $dataOrderCustomers = $this->_reportOrderCollectionFactory
            ->joinCustomerName()
            ->groupByCustomer()
            ->addOrdersCount()
            ->addSumAvgTotals()
            ->addFieldToFilter('status', 'complete')
            ->addAttributeToFilter('created_at', $this->getDateRange(1));

        $resellerGroups = $this->_resellerGroupCollectionFactory->create()->setOrder('group_rank', 'asc');

        $configTimeForDemotionConsideration = ($this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Data::XML_PATH_TIME_FOR_DEMOTION_CONSIDERATION))
            ? $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Data::XML_PATH_TIME_FOR_DEMOTION_CONSIDERATION)
            : $this->_configTimeForDemotionConsideration;

        $configAmountForDemotionConsideration = $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Data::XML_PATH_AMOUNT_FOR_DEMOTION_CONSIDERATION);

        $highestLevel = $resellerGroups->getLastItem();
        foreach ($resellerGroups as $resellerGroup) {
            $allIdsResellerGroups[] = $resellerGroup->getId();
        }

        foreach ($resellerGroups as $resellerGroup) {
            $customDataOfReseller = $this->_resellerGroupFactory->create()->load($resellerGroup->getId());
            $customersOfGroup = $customDataOfReseller->getCustomer();

            //check is reseller and update reseller member
            if ($dataOrderCustomers->count()) {
                foreach ($dataOrderCustomers as $dataOrderCustomer) {
                    if (in_array($dataOrderCustomer->getCustomerId(), $customersOfGroup)) {
                        //update level of reseller to new reseller group
                        if ($resellerGroup->getGroupRank() < $highestLevel->getGroupRank()) {
                            $idResellerLevelUp = $allIdsResellerGroups[array_search($resellerGroup->getId(),
                                $allIdsResellerGroups) + 1];
                            $dataResellerUp = $this->_resellerGroupFactory->create()->load($idResellerLevelUp);
                            if ($dataOrderCustomer->getOrdersSumAmount() >= $dataResellerUp->getMinimumSpentOfMonth()) {
                                $model = $this->_objectManager->create('Tigren\Reseller\Model\ResellerGroup');
                                $model->load($resellerGroup->getId());
                                $model->setData($resellerGroup->getData());
                                $model->setCustomerLevel(
                                    [
                                        'customer_id' => $dataOrderCustomer->getCustomerId(),
                                        'level_up_group_id' => $idResellerLevelUp,
                                        'action' => \Tigren\Reseller\Model\ResellerGroup::ACTION_UPDATE_RESELLER_MEMBER
                                    ]
                                );
                                try {
                                    $model->save();
                                    //send email to Reseller
                                    $this->_resellerEmailHelper->resellerSendEmail(
                                        $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::RESELLER_UPDATE_LEVEL_TEMPLATE),
                                        [],
                                        $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::XML_PATH_SENDER_EMAIL),
                                        $dataOrderCustomer->getCustomerEmail()
                                    );
                                    $this->_logger->alert("Reseller Module: " . $dataOrderCustomer->getCustomerName() . " level up!");
                                } catch (\Exception $e) {
                                    $this->_logger->error("Reseller Module: Can't update level customer! " . $e->getMessage());
                                }
                            }
                        }
                    }
                }
            }
            //check sales in 3 month of reseller member
            if (count($customersOfGroup)) {
                foreach ($customersOfGroup as $resellerMember) {
                    $salesInCustomMonth = $this->checkOrderOfCustomerInCustomMonth($resellerMember,
                        $configTimeForDemotionConsideration);
                    if (!$salesInCustomMonth->getSize()) {
                        $resellerData = $this->getCustomerData($resellerMember);
                        $model = $this->_objectManager->create('Tigren\Reseller\Model\ResellerGroup');
                        $model->load($resellerGroup->getId());
                        $model->setData($resellerGroup->getData());
                        $model->setCustomerLevel(
                            [
                                'customer_id' => $resellerMember,
                                'level_up_group_id' => null,
                                'action' => \Tigren\Reseller\Model\ResellerGroup::ACTION_DELETE_RESELLER_MEMBER
                            ]
                        );
                        try {
                            $model->save();
                            //send email to Reseller
                            $this->_resellerEmailHelper->resellerSendEmail(
                                $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::RESELLER_CHANGE_TO_SIMPLE_CUSTOMER_EMAIL_TEMPLATE),
                                [],
                                $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::XML_PATH_SENDER_EMAIL),
                                $resellerData->getEmail()
                            );
                            $this->_logger->alert("Reseller Module: " . $resellerData->getFirstname() . ' ' . $resellerData->getLastname() . " changed to simple customer!");
                        } catch (\Exception $e) {
                            $this->_logger->error("Reseller Module: Can't change reseller to simple customer! " . $e->getMessage());
                        }
                    } else {
                        $salesOfReseller = $salesInCustomMonth->getFirstItem();
                        if ((float)$salesOfReseller->getOrdersSumAmount() <= (float)$configAmountForDemotionConsideration) {
                            $resellerData = $this->getCustomerData($resellerMember);
                            $model = $this->_objectManager->create('Tigren\Reseller\Model\ResellerGroup');
                            $model->load($resellerGroup->getId());
                            $model->setData($resellerGroup->getData());
                            $model->setCustomerLevel(
                                [
                                    'customer_id' => $resellerMember,
                                    'level_up_group_id' => null,
                                    'action' => \Tigren\Reseller\Model\ResellerGroup::ACTION_DELETE_RESELLER_MEMBER
                                ]
                            );
                            try {
                                $model->save();

                                //send email to Reseller
                                $this->_resellerEmailHelper->resellerSendEmail(
                                    $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::RESELLER_CHANGE_TO_SIMPLE_CUSTOMER_EMAIL_TEMPLATE),
                                    [],
                                    $this->_resellerHelper->getScopeConfig(\Tigren\Reseller\Helper\Email::XML_PATH_SENDER_EMAIL),
                                    $resellerData->getEmail()
                                );
                                $this->_logger->alert("Reseller Module: " . $resellerData->getFirstname() . ' ' . $resellerData->getLastname() . " changed to simple customer!");
                            } catch (\Exception $e) {
                                $this->_logger->error("Reseller Module: Can't change reseller to simple customer! " . $e->getMessage());
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @param $customMonth
     * @return array
     */
    public function getDateRange($customMonth)
    {
        $now = $this->_timeZone->date($this->_dateTime->gmtDate())->format('Y-m-d H:i:s');
        $day = $this->_timeZone->date($now)->format('d');
        $month = $this->_timeZone->date($now)->format('m');
        $year = $this->_timeZone->date($now)->format('Y');
        $subThreeMonth = mktime(0, 0, 0, (int)$month - $customMonth, $day, $year);
        return [
            'from' => date('Y-m-d H:i:s', $subThreeMonth),
            'to' => $now
        ];
    }

    /**
     * @param $customerId
     * @param $customMonth
     * @return \Magento\Reports\Model\ResourceModel\Order\Collection
     */
    public function checkOrderOfCustomerInCustomMonth($customerId, $customMonth)
    {
        $dataOrderCustomers = $this->_reportOrderCollectionFactory
            ->joinCustomerName()
            ->groupByCustomer()
            ->addOrdersCount()
            ->addSumAvgTotals()
            ->addFieldToFilter('customer_id', $customerId)
            ->addFieldToFilter('status', 'complete')
            ->addAttributeToFilter('created_at', $this->getDateRange($customMonth));
        return $dataOrderCustomers;
    }

    /**
     * @param $customerId
     * @return mixed
     */
    public function getCustomerData($customerId)
    {
        return $this->_customerFactory->create()->load($customerId);
    }
}
