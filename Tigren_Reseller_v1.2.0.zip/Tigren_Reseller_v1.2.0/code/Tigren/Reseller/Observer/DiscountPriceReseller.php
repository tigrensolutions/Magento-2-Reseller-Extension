<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Observer;

use Magento\Framework\Event\ObserverInterface;

/**
 * Class DiscountPriceReseller
 * @package Tigren\Reseller\Observer
 */
class DiscountPriceReseller implements ObserverInterface
{
    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $item = $observer->getEvent()->getData('quote_item');
        $item = ($item->getParentItem() ? $item->getParentItem() : $item);
        $price = $item->getProduct()->getPriceInfo()->getPrice('final_price')->getValue();
        $item->setCustomPrice($price);
        $item->setOriginalCustomPrice($price);
        $item->getProduct()->setIsSuperMode(true);
    }
}
