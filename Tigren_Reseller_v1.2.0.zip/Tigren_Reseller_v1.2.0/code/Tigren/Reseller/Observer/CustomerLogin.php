<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Observer;

use Magento\Framework\Event\ObserverInterface;

/**
 * Class CustomerLogin
 * @package Tigren\Reseller\Observer
 */
class CustomerLogin implements ObserverInterface
{
    protected $_resellerGroupFactory;

    protected $_resellerGroupCollectionFactory;

    protected $_checkoutSession;
    /**
     * @var \Magento\Customer\Api\CustomerRepositoryInterface
     */
    protected $_customerRepositoryInterface;
    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    protected $_sessionManager;

    /**
     * CustomerLogin constructor.
     * @param \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface
     * @param \Magento\Framework\Session\SessionManagerInterface $sessionManager
     */
    public function __construct
    (
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory $resellerGroupCollectionFactory,
        \Tigren\Reseller\Model\ResellerGroup $resellerGroupFactory,
        \Magento\Framework\Session\SessionManagerInterface $sessionManager
    ) {
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
        $this->_sessionManager = $sessionManager;
        $this->_checkoutSession = $checkoutSession;
        $this->_resellerGroupCollectionFactory = $resellerGroupCollectionFactory;
        $this->_resellerGroupFactory = $resellerGroupFactory;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return $this|void
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $customerEvent = $observer->getEvent()->getCustomer();
        $customerId = $customerEvent->getId();
        $customer = $this->_customerRepositoryInterface->getById($customerId);
        $quote = $this->_checkoutSession->getQuote()->loadByCustomer($customerId);
        $quoteItems = $quote->getAllItems();
        $newSubTotals = 0;
        foreach($quoteItems as $item){
            $item = ($item->getParentItem() ? $item->getParentItem() : $item);
            $productPrice = $item->getProduct()->getPriceInfo()->getPrice('final_price')->getValue();
            $itemPrice = $item->getPrice();

            if($itemPrice == $productPrice)
            {
                $resellerGroupOfCustomer = $this->getResellerGroupOfCustomer($customerId);
                $newPrice = $itemPrice * ((100 - (int)$resellerGroupOfCustomer['discount']) / 100);
                $item->setCustomPrice($newPrice);
                $item->setOriginalCustomPrice($newPrice);
                $item->getProduct()->setIsSuperMode(true);
                $item->save();
                $newSubTotals += $newPrice * $item->getQty();
            }else{
                $newSubTotals += $item->getPrice() * $item->getQty();
                continue;
            }
        }
        $quote->setSubtotal($newSubTotals);
        $quote->setBaseSubtotal($newSubTotals);
        $quote->save();
        $this->_sessionManager->setResellerCustomerId($customer->getId());
        return $this;
    }

    /**
     * @return mixed|null
     */
    public function getResellerGroupOfCustomer($customerId)
    {
        $this->_sessionManager->start();
        $resellerGroups = $this->_resellerGroupCollectionFactory->create();
        $dataReseller = null;
        foreach ($resellerGroups as $resellerGroup) {
            $customDataGroup = $this->_resellerGroupFactory->load($resellerGroup->getId())->getData();
            if (!empty($customDataGroup['customer'])) {
                if (in_array($customerId, $customDataGroup['customer'])) {
                    $dataReseller = $customDataGroup;
                }
            }
        }

        return $dataReseller;
    }
}