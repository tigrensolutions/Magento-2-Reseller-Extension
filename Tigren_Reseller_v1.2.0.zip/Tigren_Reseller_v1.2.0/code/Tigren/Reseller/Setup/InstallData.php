<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Setup;

use Magento\Framework\Setup;

/**
 * Class InstallData
 * @package Tigren\Reseller\Setup
 */
class InstallData implements Setup\InstallDataInterface
{
    /**
     * @var Setup\SampleData\Executor
     */
    protected $executor;
    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_datetime;

    /**
     * InstallData constructor.
     * @param Setup\SampleData\Executor $executor
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
     */
    public function __construct(
        Setup\SampleData\Executor $executor,
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
    ) {
        $this->executor = $executor;
        $this->_datetime = $dateTime;
    }

    /**
     * {@inheritdoc}
     */
    public function install(Setup\ModuleDataSetupInterface $setup, Setup\ModuleContextInterface $moduleContext)
    {
        $setup->startSetup();

        $groupDefault = [
            [
                'group_name' => 'Silver',
                'minimum_spent_of_month' => 500,
                'customer_group' => '1',
                'group_rank' => 1,
                'discount' => 10,
                'created_at' => $this->_datetime->gmtDate(),
            ],
            [
                'group_name' => 'Gold',
                'minimum_spent_of_month' => 1000,
                'customer_group' => '1',
                'group_rank' => 2,
                'discount' => 15,
                'created_at' => $this->_datetime->gmtDate(),
            ],
            [
                'group_name' => 'Platinum',
                'minimum_spent_of_month' => 2000,
                'customer_group' => '1',
                'group_rank' => 3,
                'discount' => 20,
                'created_at' => $this->_datetime->gmtDate(),
            ],
        ];

        $setup->getConnection()->insertMultiple($setup->getTable('tigren_reseller_group'), $groupDefault);

        $setup->endSetup();
    }
}
