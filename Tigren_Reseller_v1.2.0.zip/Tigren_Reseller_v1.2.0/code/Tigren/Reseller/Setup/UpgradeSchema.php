<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;

/**
 * Class UpgradeSchema
 * @package Tigren\Reseller\Setup
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @throws \Zend_Db_Exception
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        if (version_compare($context->getVersion(), '1.1.0', '<')) {
            $table = $installer->getConnection()
                ->newTable($installer->getTable('tigren_reseller_submitted'))
                ->addColumn(
                    'submitted_id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Id'
                )
                ->addColumn(
                    'customer_id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    ['unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Customer'
                )
                ->addColumn(
                    'website',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    ['nullable' => false, 'default' => ''],
                    'Website'
                )
                ->addColumn(
                    'answer',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    null,
                    ['nullable' => false],
                    'Answer'
                )
                ->addColumn(
                    'status',
                    \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                    null,
                    ['nullable' => false, 'default' => 0],
                    'Status'
                )
                ->addColumn(
                    'created_at',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                    null,
                    [],
                    'Created At'
                )
                ->addForeignKey(
                    $installer->getFkName('tigren_reseller_submitted', 'customer_id', 'customer_entity', 'entity_id'),
                    'customer_id',
                    $installer->getTable('customer_entity'),
                    'entity_id',
                    \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
                )
                ->setComment('Reseller Submitted');

            $installer->getConnection()->createTable($table);
        }

        if (version_compare($context->getVersion(), '1.2.0', '<')) {
            $table = $setup->getTable('tigren_reseller_group');
            $connection = $setup->getConnection();

            $connection->addIndex(
                $table,
                \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE,
                'group_rank',
                \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE
            );
        }

        if (version_compare($context->getVersion(), '1.3.0', '<')) {
            $table = $setup->getTable('tigren_reseller_submitted');
            $connection = $setup->getConnection();

            $connection->dropColumn($table, 'website');

            $connection->addColumn(
                $table,
                'company',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    'default' => '',
                    'nullable' => false,
                    'comment' => 'Company'
                ]
            );
            $connection->addColumn(
                $table,
                'abn',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    'default' => '',
                    'nullable' => false,
                    'comment' => 'Resale Number/Tax ID'
                ]
            );
            $connection->addColumn(
                $table,
                'telephone',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    'default' => '',
                    'nullable' => false,
                    'comment' => 'Telephone'
                ]
            );
            $connection->addColumn(
                $table,
                'reseller_mobile',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    'default' => '',
                    'nullable' => false,
                    'comment' => 'Reseller Mobile'
                ]
            );
            $connection->addColumn(
                $table,
                'address_1',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    'default' => '',
                    'nullable' => false,
                    'comment' => 'Address 1'
                ]
            );
            $connection->addColumn(
                $table,
                'address_2',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    'default' => null,
                    'nullable' => true,
                    'comment' => 'Address 2'
                ]
            );
            $connection->addColumn(
                $table,
                'city',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    'default' => '',
                    'nullable' => false,
                    'comment' => 'City'
                ]
            );
            $connection->addColumn(
                $table,
                'state',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    'default' => '',
                    'nullable' => false,
                    'comment' => 'State'
                ]
            );
            $connection->addColumn(
                $table,
                'postcode',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    'default' => '',
                    'nullable' => false,
                    'comment' => 'Zip/Postal Code'
                ]
            );
            $connection->addColumn(
                $table,
                'country',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    'default' => '',
                    'nullable' => false,
                    'comment' => 'Country'
                ]
            );
            $connection->addColumn(
                $table,
                'hear_about_us',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    'default' => '',
                    'nullable' => false,
                    'comment' => 'Hear about us'
                ]
            );
            $connection->addColumn(
                $table,
                'customer_email',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    'default' => '',
                    'nullable' => false,
                    'comment' => 'Customer Email'
                ]
            );
        }

        if (version_compare($context->getVersion(), '1.3.1', '<')) {
            $table = $setup->getTable('tigren_reseller_group_customer');
            $connection = $setup->getConnection();

            $connection->addColumn(
                $table,
                'base_customer_group',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    'default' => null,
                    'nullable' => true,
                    'comment' => 'Base Customer Group'
                ]
            );
        }

        $installer->endSetup();
    }
}
