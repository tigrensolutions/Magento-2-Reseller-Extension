<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Plugin;

/**
 * Class ChangePrice
 * @package Tigren\Reseller\Plugin
 */
class ChangePrice
{
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_sessionCustomer;

    /**
     * @var \Tigren\Reseller\Model\ResellerGroup
     */
    protected $_resellerGroupFactory;

    /**
     * @var \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory
     */
    protected $_resellerGroupCollectionFactory;

    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    protected $_sessionManager;

    /**
     * ChangePrice constructor.
     * @param \Magento\Customer\Model\Session $sessionCustomer
     * @param \Tigren\Reseller\Model\ResellerGroup $resellerGroupnFactory
     * @param \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory $resellerGroupCollectionFactory
     * @param \Magento\Framework\Session\SessionManagerInterface $sessionManager
     */
    public function __construct(
        \Magento\Customer\Model\Session $sessionCustomer,
        \Tigren\Reseller\Model\ResellerGroup $resellerGroupnFactory,
        \Tigren\Reseller\Model\ResourceModel\ResellerGroup\CollectionFactory $resellerGroupCollectionFactory,
        \Magento\Framework\Session\SessionManagerInterface $sessionManager
    )
    {
        $this->_sessionCustomer = $sessionCustomer;
        $this->_resellerGroupFactory = $resellerGroupnFactory;
        $this->_resellerGroupCollectionFactory = $resellerGroupCollectionFactory;
        $this->_sessionManager = $sessionManager;
    }

    /**
     * @param \Magento\Catalog\Model\Product $subject
     * @param $result
     * @return float|int
     */
    public function afterGetPrice(\Magento\Catalog\Model\Product $subject, $result)
    {
        $resellerGroupOfCustomer = $this->getResellerGroupOfCustomer();
        $newPrice = $result * ((100 - (int)$resellerGroupOfCustomer['discount']) / 100);
        if (is_array($resellerGroupOfCustomer)) {
            return $newPrice;
        } else {
            return $result;
        }
    }

    /**
     * @return mixed|null
     */
    public function getResellerGroupOfCustomer()
    {
        $customerId = null;
        $this->_sessionManager->start();
        $sessionCustomerId = $this->_sessionManager->getResellerCustomerId();
        $resellerGroups = $this->_resellerGroupCollectionFactory->create();
        $dataReseller = null;
        foreach ($resellerGroups as $resellerGroup) {
            $customDataGroup = $this->_resellerGroupFactory->load($resellerGroup->getId())->getData();
            if (!empty($customDataGroup['customer'])) {
                if (in_array($sessionCustomerId, $customDataGroup['customer'])) {
                    $dataReseller = $customDataGroup;
                }
            }
        }

        return $dataReseller;
    }
}