<?php
/**
 * Copyright (c) 2017 www.tigren.com
 */

namespace Tigren\Reseller\Helper;

/**
 * Class Email
 * @package Tigren\Reseller\Helper
 */
class Email extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     *
     */
    const RESELLER_REVIEW_STATUS_EMAIL_TEMPLATE = 'reseller/email/reseller_review_status_email_template';
    /**
     *
     */
    const RESELLER_REQUEST_SUBMITTED_EMAIL_TEMPLATE = 'reseller/email/reseller_request_submitted_email_template';
    /**
     *
     */
    const RESELLER_APPROVE_SUBMITTED_EMAIL_TEMPLATE = 'reseller/email/reseller_approve_submitted_email_template';
    /**
     *
     */
    const RESELLER_DECLINE_SUBMITTED_EMAIL_TEMPLATE = 'reseller/email/reseller_decline_submitted_email_template';
    /**
     *
     */
    const RESELLER_UPDATE_LEVEL_TEMPLATE = 'reseller/email/reseller_update_level_template';
    /**
     *
     */
    const RESELLER_CHANGE_TO_SIMPLE_CUSTOMER_EMAIL_TEMPLATE = 'reseller/email/reseller_change_to_simple_customer_email_template';
    /**
     *
     */
    const RESELLER_MARKETING_EMAIL_TEMPLATE = 'reseller/email/reseller_marketing_email_template';

    /**
     *
     */
    const XML_PATH_SEND_EMAIL_TO = 'reseller/email/recipient_email';
    /**
     *
     */
    const XML_PATH_SENDER_EMAIL = 'reseller/email/sender_email_identity';

    /**
     * @var \Magento\Framework\App\Helper\Context
     */
    protected $_scopeConfig;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\Translate\Inline\StateInterface
     */
    protected $_inlineTranslation;

    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;

    /**
     * @var
     */
    protected $_temp_id;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $_logger;

    /**
     * Email constructor.
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Psr\Log\LoggerInterface $logger
    ) {
        $this->_scopeConfig = $context;
        parent::__construct($context);
        $this->_storeManager = $storeManager;
        $this->_inlineTranslation = $inlineTranslation;
        $this->_transportBuilder = $transportBuilder;
        $this->_logger = $logger;
    }

    /**
     * @return \Magento\Store\Api\Data\StoreInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getStore()
    {
        return $this->_storeManager->getStore();
    }

    /**
     * @param $template
     * @param $emailTemplateVariables
     * @param $senderInfo
     * @param $receiverInfo
     * @throws \Magento\Framework\Exception\MailException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function resellerSendEmail($template, $emailTemplateVariables, $senderInfo, $receiverInfo)
    {
        try {
            $this->_temp_id = $this->getTemplateId($template);
            $this->_inlineTranslation->suspend();
            $this->generateTemplate($emailTemplateVariables, $senderInfo, $receiverInfo);
            $transport = $this->_transportBuilder->getTransport();
            $transport->sendMessage();
            $this->_inlineTranslation->resume();

            $this->_logger->alert('Reseller Module: Sent email to ' . $receiverInfo);
        } catch (\Exception $e) {
            $this->_logger->alert('Reseller Module: Cannot send email to ' . $receiverInfo);
        }
    }

    /**
     * @param $templateId
     * @return mixed
     */
    public function getTemplateId($templateId)
    {
        return $templateId;
    }

    /**
     * @param $emailTemplateVariables
     * @param $senderInfo
     * @param $receiverInfo
     * @return $this
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function generateTemplate($emailTemplateVariables, $senderInfo, $receiverInfo)
    {
        $this->_transportBuilder->setTemplateIdentifier($this->_temp_id)
            ->setTemplateOptions(
                [
                    'area' => \Magento\Backend\App\Area\FrontNameResolver::AREA_CODE,
                    'store' => $this->_storeManager->getStore()->getId(),
                ]
            )
            ->setTemplateVars($emailTemplateVariables)
            ->setFrom($senderInfo)
            ->addTo($receiverInfo, 'admin');

        return $this;
    }
}